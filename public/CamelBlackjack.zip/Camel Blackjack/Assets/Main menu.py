import pygame
import os
import time

pygame.init()


WIDTH, HEIGHT = 1280, 720
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Camel BlackJack")

FPS = 60
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
RED = (250, 0, 0)


TABLE = pygame.image.load(os.path.join('Assets', 'table.png'))

MENU_BACKGROUND = pygame.image.load(os.path.join('Assets', 'menu_background.png'))
PLAY_WHITE = pygame.image.load(os.path.join('Assets', 'play_button.png'))
PLAY_RED = pygame.image.load(os.path.join('Assets', 'play_button_2.png'))

QUIT_WHITE = pygame.image.load(os.path.join('Assets', 'quit_button.png'))
QUIT_RED = pygame.image.load(os.path.join('Assets', 'quit_button_2.png'))

MAIN_PLAY_BUTTON = pygame.Rect(WIDTH//2- 235.5, HEIGHT//2 -140, 471 , 103) # MAIN PLAY BUTTON RECT
MAIN_QUIT_BUTTON = pygame.Rect(WIDTH//2- 235.5, HEIGHT//2, 471 , 103) # MAIN QUIT BUTTON RECT

def is_over(rect, pos):
    return True if rect.collidepoint(pos[0], pos[1]) else False

def main():
    WIN.fill(BLACK)
    WIN.blit(PLAY_WHITE,(WIDTH//2- 235.5, HEIGHT//2 -140))
    WIN.blit(QUIT_WHITE,(WIDTH//2- 235.5, HEIGHT//2))
    WIN.blit(MENU_BACKGROUND,(0,0))
    clock = pygame.time.Clock()
    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                exit()

        pygame.display.update()


        mouse = pygame.mouse.get_pos()
        if is_over(MAIN_PLAY_BUTTON, mouse):

            WIN.blit(PLAY_RED,(WIDTH//2- 235.5, HEIGHT//2 -140))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                WIN.fill(BLACK)
                print("clicked")
                time.sleep(0.5)
            else:
                #print("MOUSE OVER BUT NOT CLICKING")
                pass

        else:
            # print('The mouse is not over the PLAY BUTTON')
            WIN.blit(PLAY_WHITE,(WIDTH//2 -235.5, HEIGHT//2 -140))
            pygame.display.update()

        if is_over(MAIN_QUIT_BUTTON, mouse):
            # print('The mouse is over the PLAY BUTTON')
            WIN.blit(QUIT_RED,(WIDTH//2- 235.5, HEIGHT//2))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONUP:
                run = False
                pygame.quit()
                exit()
            else:
                pass
                #print("MOUSE OVER BUT NOT CLICKING")


        else:
            #print('The mouse is not over the PLAY BUTTON')
            WIN.blit(QUIT_WHITE,(WIDTH//2 -235.5, HEIGHT//2))
            pygame.display.update()



    pygame.quit()

if __name__ == "__main__":
    main()