
# DEALER BLACKJACK
# SPLIT OPTION

import random
import pygame
import os
pygame.init()
pygame.font.init()


WIDTH, HEIGHT = 1280, 720
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Camel BlackJack")

FPS = 144
WHITE = (0, 255, 0)
BLACK = (0, 0, 0)
RED = (250, 0, 0)
GRAY = (160, 160, 160)
CARD_WIDTH, CARD_HEIGHT = 68, 92
CARD_POS_WIDTH = WIDTH//2 -34
CARD_POS_HEIGHT = HEIGHT//2 +70
D_CARD_POS_WIDTH = WIDTH//2 - 210
D_CARD_POS_HEIGHT = 135
WHITE = (255, 255, 230)
PLAYER_CHIPS = [500]

# WIDTH , Height, SIZE
TABLE = pygame.image.load(os.path.join('Assets', 'table.png'))

CHIP_1_WHITE = pygame.image.load(os.path.join('Assets', 'chip_1_white.png'))
CHIP_1_RED = pygame.image.load(os.path.join('Assets', 'chip_1_red.png'))

CHIP_2_WHITE = pygame.image.load(os.path.join('Assets', 'chip_5_white.png'))
CHIP_2_RED = pygame.image.load(os.path.join('Assets', 'chip_5_red.png'))

CHIP_3_WHITE = pygame.image.load(os.path.join('Assets', 'chip_10_white.png'))
CHIP_3_RED = pygame.image.load(os.path.join('Assets', 'chip_10_red.png'))

CHIP_4_WHITE = pygame.image.load(os.path.join('Assets', 'chip_25_white.png'))
CHIP_4_RED = pygame.image.load(os.path.join('Assets', 'chip_25_red.png'))

CHIP_5_WHITE = pygame.image.load(os.path.join('Assets', 'chip_50_white.png'))
CHIP_5_RED = pygame.image.load(os.path.join('Assets', 'chip_50_red.png'))

DEAL_WHITE = pygame.image.load(os.path.join('Assets', 'deal_white.png'))
DEAL_RED = pygame.image.load(os.path.join('Assets', 'deal_red.png'))

BET_AMOUNT = pygame.image.load(os.path.join('Assets', 'bet_amount.png'))

CHIPS_AGAIN_WHITE = pygame.image.load(os.path.join('Assets', 'again_button_40.png'))
CHIPS_AGAIN_RED = pygame.image.load(os.path.join('Assets', 'again_button_2_40.png'))
CHIPS_AGAIN_RECT = pygame.Rect(850  -15.5, 443 -15.5, 31 , 31) # Again BUTTON RECT

CHIPS_SHOW = pygame.image.load(os.path.join('Assets', 'chips.png'))

CHIP_1_BUTTON = pygame.Rect(400 -42.5, 360 -42.5, 85, 85)
CHIP_2_BUTTON = pygame.Rect(520 -42.5, 360 -42.5, 85, 85)
CHIP_3_BUTTON = pygame.Rect(640 -42.5, 360 -42.5, 85, 85)
CHIP_4_BUTTON = pygame.Rect(760 -42.5, 360 -42.5, 85, 85)
CHIP_5_BUTTON = pygame.Rect(880 -42.5, 360 -42.5, 85, 85)
DEAL_BUTTON = pygame.Rect((640 -166, 527 -37, 332, 74))

BUTTON_DOUBLE_BRIGHT = pygame.image.load(os.path.join('Assets', 'double_bright.png'))
BUTTON_DOUBLE_LIGHT = pygame.image.load(os.path.join('Assets', 'double_light.png'))
BUTTON_DOUBLE_RED = pygame.image.load(os.path.join('Assets', 'double_red.png'))
BUTTON_DOUBLE_RECT = pygame.Rect(360 - 60, 670 - 32, 120 , 64) # Double BUTTON RECT

BUTTON_STAND_BRIGHT = pygame.image.load(os.path.join('Assets', 'stand_bright.png'))
BUTTON_STAND_LIGHT = pygame.image.load(os.path.join('Assets', 'stand_light.png'))
BUTTON_STAND_RED = pygame.image.load(os.path.join('Assets', 'stand_red.png'))
BUTTON_STAND_RECT = pygame.Rect(535 - 60, 670 - 32, 120 , 64) # Stand BUTTON RECT

BUTTON_HIT_BRIGHT = pygame.image.load(os.path.join('Assets', 'hit_bright.png'))
BUTTON_HIT_LIGHT = pygame.image.load(os.path.join('Assets', 'hit_light.png'))
BUTTON_HIT_RED = pygame.image.load(os.path.join('Assets', 'hit_red.png'))
BUTTON_HIT_RECT = pygame.Rect(736 - 60, 670 - 32, 120 , 64) # Hit BUTTON RECT

BUTTON_SPLIT_BRIGHT = pygame.image.load(os.path.join('Assets', 'split_bright.png'))
BUTTON_SPLIT_LIGHT = pygame.image.load(os.path.join('Assets', 'split_light.png'))
BUTTON_SPLIT_RED = pygame.image.load(os.path.join('Assets', 'split_red.png'))
BUTTON_SPLIT_RECT = pygame.Rect(916 - 60, 670 - 32, 120 , 64) # Split BUTTON RECT

BUTTON_AGAIN_WHITE = pygame.image.load(os.path.join('Assets', 'again_button.png'))
BUTTON_AGAIN_RED = pygame.image.load(os.path.join('Assets', 'again_button_2.png'))
BUTTON_AGAIN_RECT = pygame.Rect(1090.00 - 102.5, 436.00 - 95, 205 , 190) # Again BUTTON RECT

MENU_BACKGROUND = pygame.image.load(os.path.join('Assets', 'menu_background.png'))
PLAY_WHITE = pygame.image.load(os.path.join('Assets', 'play_button.png'))
PLAY_RED = pygame.image.load(os.path.join('Assets', 'play_button_2.png'))

QUIT_WHITE = pygame.image.load(os.path.join('Assets', 'quit_button.png'))
QUIT_RED = pygame.image.load(os.path.join('Assets', 'quit_button_2.png'))

MAIN_PLAY_BUTTON = pygame.Rect(WIDTH//2- 235.5, HEIGHT//2 -140, 471 , 103) # MAIN PLAY BUTTON RECT
MAIN_QUIT_BUTTON = pygame.Rect(WIDTH//2- 235.5, HEIGHT//2 -20, 471 , 103) # MAIN QUIT BUTTON RECT
CHANGE_BUTTON = pygame.Rect(640 -118.5, 484 -28.5, 237 , 53) # MAIN QUIT BUTTON RECT

WIN_IMG = pygame.image.load(os.path.join('Assets', 'win.png'))
LOSE_IMG = pygame.image.load(os.path.join('Assets', 'lose.png'))
AGAIN_IMG = pygame.image.load(os.path.join('Assets', 'again_text.png'))

CHANGE_WHITE = pygame.image.load(os.path.join('Assets', 'change_white.png'))
CHANGE_RED = pygame.image.load(os.path.join('Assets', 'change_red.png'))

TOTAL_IMG = pygame.image.load(os.path.join('Assets', 'total.png'))
DEALER_TOTAL_IMG = pygame.image.load(os.path.join('Assets', 'total_dealer.png'))
TOTAL2_IMG = pygame.image.load(os.path.join('Assets', 'total2.png'))
DEALER_TOTAL2_IMG = pygame.image.load(os.path.join('Assets', 'total_dealer2.png'))

TABLE_2 = pygame.image.load(os.path.join('Assets', 'table2.png'))

CARD_2 = pygame.image.load(os.path.join('Assets', 'camel_card_2.png'))

CARD_3 = pygame.image.load(os.path.join('Assets', 'camel_card_3.png'))

CARD_4 = pygame.image.load(os.path.join('Assets', 'camel_card_4.png'))

CARD_5 = pygame.image.load(os.path.join('Assets', 'camel_card_5.png'))

CARD_6 = pygame.image.load(os.path.join('Assets', 'camel_card_6.png'))

CARD_7 = pygame.image.load(os.path.join('Assets', 'camel_card_7.png'))

CARD_8 = pygame.image.load(os.path.join('Assets', 'camel_card_8.png'))

CARD_9 = pygame.image.load(os.path.join('Assets', 'camel_card_9.png'))

CARD_10 = pygame.image.load(os.path.join('Assets', 'camel_card_10.png'))

CARD_J = pygame.image.load(os.path.join('Assets', 'camel_card_J.png'))

CARD_Q = pygame.image.load(os.path.join('Assets', 'camel_card_Q.png'))

CARD_K = pygame.image.load(os.path.join('Assets', 'camel_card_K.png'))

CARD_A = pygame.image.load(os.path.join('Assets', 'camel_card_A.png'))

SMALL_1 = pygame.image.load(os.path.join('Assets', '1_small.png'))
SMALL_5 = pygame.image.load(os.path.join('Assets', '5_small.png'))
SMALL_10 = pygame.image.load(os.path.join('Assets', '10_small.png'))
SMALL_25 = pygame.image.load(os.path.join('Assets', '25_small.png'))
SMALL_50 = pygame.image.load(os.path.join('Assets', '50_small.png'))

MINI_TABLE = pygame.image.load(os.path.join('Assets', 'mini_table.png'))
MINI_TABLE2 = pygame.image.load(os.path.join('Assets', 'mini_table2.png'))

DCARD_2 = pygame.transform.rotate(CARD_2,180)
DCARD_3 = pygame.transform.rotate(CARD_3,180)
DCARD_4 = pygame.transform.rotate(CARD_4,180)
DCARD_5 = pygame.transform.rotate(CARD_5,180)
DCARD_6 = pygame.transform.rotate(CARD_6,180)
DCARD_7 = pygame.transform.rotate(CARD_7,180)
DCARD_8 = pygame.transform.rotate(CARD_8,180)
DCARD_9 = pygame.transform.rotate(CARD_9,180)
DCARD_10 = pygame.transform.rotate(CARD_10,180)
DCARD_J = pygame.transform.rotate(CARD_J,180)
DCARD_Q = pygame.transform.rotate(CARD_Q,180)
DCARD_K = pygame.transform.rotate(CARD_K,180)
DCARD_A = pygame.transform.rotate(CARD_A,180)


CARD_BACK = pygame.image.load(os.path.join('Assets', 'camel_card_back.png'))


CLICK_SOUND = pygame.mixer.Sound(os.path.join('Sounds', 'click.wav'))
CHIP_SOUND = pygame.mixer.Sound(os.path.join('Sounds', 'chip_sound.wav'))

deck = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]*24
deck2 = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]*24
width_remove = []
height_remove = []
d_width_remove = []
chips_on_table = []
table_list = [1]
double_check = []
class Chips:
    def __init__(self, amount):
        self.amount = amount
        self.amount = [0]
    def add_chips_1(self):
        if sum(PLAYER_CHIPS) < sum(self.amount) +1:
            pass
        elif sum(PLAYER_CHIPS) > sum(self.amount) +1:
            self.amount.append(1)
            if 1 in chips_on_table:
                pass
            else:
                chips_on_table.append(1)
        elif sum(PLAYER_CHIPS) == sum(self.amount) +1:
            self.amount.append(1)
            if 1 in chips_on_table:
                pass
            else:
                chips_on_table.append(1)
        elif sum(PLAYER_CHIPS) <= 0:
            pass
    def add_chips_5(self):
        if sum(PLAYER_CHIPS) < sum(self.amount) + 5:
            pass
        elif sum(PLAYER_CHIPS) > sum(self.amount) + 5:
            self.amount.append(5)
            if 5 in chips_on_table:
                pass
            else:
                chips_on_table.append(5)
        elif sum(PLAYER_CHIPS) == sum(self.amount) + 5:
            self.amount.append(5)
            if 5 in chips_on_table:
                pass
            else:
                chips_on_table.append(5)
        elif sum(PLAYER_CHIPS) <= 0:
            pass
    def add_chips_10(self):
        if sum(PLAYER_CHIPS) < sum(self.amount) + 10:
            pass
        elif sum(PLAYER_CHIPS) > sum(self.amount) + 10:
            self.amount.append(10)
            if 10 in chips_on_table:
                pass
            else:
                chips_on_table.append(10)
        elif sum(PLAYER_CHIPS) == sum(self.amount) + 10:
            self.amount.append(10)
            if 10 in chips_on_table:
                pass
            else:
                chips_on_table.append(10)
        elif sum(PLAYER_CHIPS) <= 0:
            pass
    def add_chips_25(self):
        if sum(PLAYER_CHIPS) < sum(self.amount) + 25:
            pass
        elif sum(PLAYER_CHIPS) > sum(self.amount) + 25:
            self.amount.append(25)
            if 25 in chips_on_table:
                pass
            else:
                chips_on_table.append(25)
        elif sum(PLAYER_CHIPS) == sum(self.amount) + 25:
            self.amount.append(25)
            if 25 in chips_on_table:
                pass
            else:
                chips_on_table.append(25)
        elif sum(PLAYER_CHIPS) <= 0:
            pass
    def add_chips_50(self):
        if sum(PLAYER_CHIPS) < sum(self.amount) + 50:
            pass
        elif sum(PLAYER_CHIPS) > sum(self.amount) + 50:
            self.amount.append(50)
            if 50 in chips_on_table:
                pass
            else:
                chips_on_table.append(50)
        elif sum(PLAYER_CHIPS) == sum(self.amount) + 50:
            self.amount.append(50)
            if 50 in chips_on_table:
                pass
            else:
                chips_on_table.append(50)
        elif sum(PLAYER_CHIPS) <= 0:
            pass

    def bet_total(self):
        x = sum(self.amount)
        return x

    def clear_bet(self):
        self.amount.clear()


class Card:
    def __init__(self, list_of_cards):
        random.shuffle(deck)
        self.list_of_cards = list_of_cards
        self.list_of_cards = []

    def player_add_card(self):
        card = deck.pop()
        if card == 2:
            self.list_of_cards.append(2)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_2, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 3:
            self.list_of_cards.append(3)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_3, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 4:
            self.list_of_cards.append(4)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_4, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 5:
            self.list_of_cards.append(5)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_5, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 6:
            self.list_of_cards.append(6)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_6, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 7:
            self.list_of_cards.append(7)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_7, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 8:
            self.list_of_cards.append(8)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_8, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 9:
            self.list_of_cards.append(9)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_9, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 10:
            self.list_of_cards.append(10)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_10, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 11:# J
            self.list_of_cards.append(10)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_J, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 12: # Q
            self.list_of_cards.append(10)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_Q, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 13: #K
            self.list_of_cards.append(10)
            WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            pygame.time.wait(1500)
            WIN.blit(CARD_K, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
            pygame.display.update()
            width_remove.append(-20)
            height_remove.append(20)
            show_total_player()
        if card == 14: #A
            if sum(self.list_of_cards) >= 11:
                self.list_of_cards.append(1)
                WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(CARD_A, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
                pygame.display.update()
                width_remove.append(-20)
                height_remove.append(20)
                show_total_player()
            elif sum(self.list_of_cards) <= 10:
                self.list_of_cards.append(11)
                WIN.blit(CARD_BACK, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(CARD_A, (CARD_POS_WIDTH - sum(width_remove), CARD_POS_HEIGHT - sum(height_remove)))
                pygame.display.update()
                width_remove.append(-20)
                height_remove.append(20)
                show_total_player()
        if sum(self.list_of_cards) >= 22:
            for i in range(len(self.list_of_cards)):
                if self.list_of_cards[i] == 11:
                    self.list_of_cards[i] = 1
                    show_total_player()
        pygame.display.update()

    def dealer_add_card(self):
        card = deck.pop()
        if len(self.list_of_cards) == 1:
            WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
            pygame.display.update()
            if card == 14:
                if 10 in self.list_of_cards:
                    self.list_of_cards.append(11)
                    pygame.time.wait(1500)
                    WIN.blit(DCARD_A, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                    pygame.display.update()
                    show_total_dealer()
                else:
                    return card
            elif card == 13 or 12 or 11 or 10:
                if 11 in self.list_of_cards:
                    self.list_of_cards.append(10)
                    pygame.time.wait(1500)
                    WIN.blit(DCARD_10, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                    pygame.display.update()
                    show_total_dealer()
                else:
                    return card
        else:
            if card == 2:
                self.list_of_cards.append(2)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_2, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 3:
                self.list_of_cards.append(3)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_3, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 4:
                self.list_of_cards.append(4)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_4, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 5:
                self.list_of_cards.append(5)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_5, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 6:
                self.list_of_cards.append(6)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_6, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 7:
                self.list_of_cards.append(7)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_7, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 8:
                self.list_of_cards.append(8)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_8, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 9:
                self.list_of_cards.append(9)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_9, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 10:
                self.list_of_cards.append(10)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_10, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 11:# J
                self.list_of_cards.append(10)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_J, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 12: # Q
                self.list_of_cards.append(10)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_Q, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 13: #K
                self.list_of_cards.append(10)
                WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                pygame.time.wait(1500)
                WIN.blit(DCARD_K, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                pygame.display.update()
                d_width_remove.append(-20)
                show_total_dealer()
            if card == 14: #A
                if sum(self.list_of_cards) >= 11:
                    self.list_of_cards.append(1)
                    WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                    pygame.display.update()
                    pygame.time.wait(1500)
                    WIN.blit(DCARD_A, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                    pygame.display.update()
                    d_width_remove.append(-20)
                    show_total_dealer()

                elif sum(self.list_of_cards) <= 10:
                    self.list_of_cards.append(11)
                    WIN.blit(CARD_BACK, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                    pygame.display.update()
                    pygame.time.wait(1500)
                    WIN.blit(DCARD_A, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                    pygame.display.update()
                    d_width_remove.append(-20)
                    show_total_dealer()

            if sum(self.list_of_cards) >= 22:
                for i in range(len(self.list_of_cards)):
                    if self.list_of_cards[i] == 11:
                        self.list_of_cards[i] = 1
                        show_total_dealer()
        pygame.display.update()

    def check_total(self):
        x = sum(self.list_of_cards)
        return x

    def clear_list(self):
        self.list_of_cards.clear()

    def check_len_of_card_list(self):
        return len(self.list_of_cards)

    def add_list(self, i):
        self.list_of_cards.append(i)

    def too_many_fix(self):
        if sum(self.list_of_cards) >= 22:
            for i in range(len(self.list_of_cards)):
                if self.list_of_cards[i] == 11:
                    self.list_of_cards[i] = 1
                    show_total_dealer()

CHIPS = Chips('BET')


def show_bet_chips():
    chips_total_font = pygame.font.SysFont('Acumin Variable Concept', 50)
    chips_show_total = chips_total_font.render(f'{CHIPS.bet_total()}', False, (0, 0, 0))
    WIN.blit(BET_AMOUNT,(640 -186, 443 -21))
    WIN.blit(chips_show_total,(720, 427.5))
    pygame.display.update()

def show_player_chips():
    player_chips_font = pygame.font.SysFont('Franklin Gothic Medium', 25)
    chips_player_show = player_chips_font.render(f'{sum(PLAYER_CHIPS)}', False, (0, 0, 0))
    WIN.blit(CHIPS_SHOW,(98 -85, 42 -25))
    WIN.blit(chips_player_show,(95, 30))
    pygame.display.update()

def chips_menu():
    CHIPS.clear_bet()
    for i in table_list:
        if i == 1:
            WIN.blit(TABLE,(0,0))
        if i == 2:
            WIN.blit(TABLE_2,(0,0))
    show_player_chips()
    show_bet_chips()
    WIN.blit(CHIP_1_WHITE,(400 -42.5, 360 -42.5))
    WIN.blit(CHIP_2_WHITE,(520 -42.5, 360 -42.5))
    WIN.blit(CHIP_3_WHITE,(640 -42.5, 360 -42.5))
    WIN.blit(CHIP_4_WHITE,(760 -42.5, 360 -42.5))
    WIN.blit(CHIP_5_WHITE,(880 -42.5, 360 -42.5))
    WIN.blit(DEAL_WHITE,(640 -166, 527 -37))
    clock = pygame.time.Clock()
    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                exit()

        pygame.display.update()


        mouse = pygame.mouse.get_pos()
        if is_over(CHIP_1_BUTTON, mouse):

            WIN.blit(CHIP_1_RED,(400 -42.5, 360 -42.5))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CHIP_SOUND.play()
                CHIPS.add_chips_1()
                show_bet_chips()
                pygame.time.wait(500)
            else:
                pass

        else:
            WIN.blit(CHIP_1_WHITE,(400 -42.5, 360 -42.5))
            pygame.display.update()

        if is_over(CHIP_2_BUTTON, mouse):

            WIN.blit(CHIP_2_RED,(520 -42.5, 360 -42.5))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CHIP_SOUND.play()
                CHIPS.add_chips_5()
                show_bet_chips()
                pygame.time.wait(500)
            else:
                pass

        else:
            WIN.blit(CHIP_2_WHITE,(520 -42.5, 360 -42.5))
            pygame.display.update()

        if is_over(CHIP_3_BUTTON, mouse):

            WIN.blit(CHIP_3_RED,(640 -42.5, 360 -42.5))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CHIP_SOUND.play()
                CHIPS.add_chips_10()
                show_bet_chips()
                pygame.time.wait(500)
            else:
                pass

        else:
            WIN.blit(CHIP_3_WHITE,(640 -42.5, 360 -42.5))
            pygame.display.update()

        if is_over(CHIP_4_BUTTON, mouse):

            WIN.blit(CHIP_4_RED,(760 -42.5, 360 -42.5))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CHIP_SOUND.play()
                CHIPS.add_chips_25()
                show_bet_chips()
                pygame.time.wait(500)
            else:
                pass

        else:
            WIN.blit(CHIP_4_WHITE,(760 -42.5, 360 -42.5))
            pygame.display.update()

        if is_over(CHIP_5_BUTTON, mouse):

            WIN.blit(CHIP_5_RED,(880 -42.5, 360 -42.5))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CHIP_SOUND.play()
                CHIPS.add_chips_50()
                show_bet_chips()
                pygame.time.wait(500)
            else:
                pass

        else:
            WIN.blit(CHIP_5_WHITE,(880 -42.5, 360 -42.5))
            pygame.display.update()

        if is_over(DEAL_BUTTON, mouse):

            WIN.blit(DEAL_RED,(640 -166, 527 -37))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CLICK_SOUND.play()
                if CHIPS.bet_total() < 1:
                    # DO NOT DEAL IF BET IS UNDER 1
                    pass
                else:
                    # TAKES CHIPS FROM PLAYER
                    PLAYER_CHIPS.append(- CHIPS.bet_total())
                    play()
                pygame.time.wait(500)
            else:
                pass

        else:
            WIN.blit(DEAL_WHITE,(640 -166, 527 -37))
            pygame.display.update()

        if is_over(CHIPS_AGAIN_RECT, mouse):

            WIN.blit(CHIPS_AGAIN_RED,(850  -15.5, 443 -15.5))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CLICK_SOUND.play()
                CHIPS.clear_bet()
                chips_on_table.clear()
                show_bet_chips()
                pygame.time.wait(500)
            else:
                pass

        else:
            WIN.blit(CHIPS_AGAIN_WHITE,(850  -15.5, 443 -15.5))
            pygame.display.update()

def play_again():
    WIN.blit(AGAIN_IMG,(530 - 410, 437 - 68.5))
    show_player_chips()
    run = True
    clock = pygame.time.Clock()
    while run:
        mouse = pygame.mouse.get_pos()
        run = True
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                exit()
        pygame.display.update()
        mouse = pygame.mouse.get_pos()

        # HANDLES THE AGAIN BUTTON
        if is_over(BUTTON_AGAIN_RECT, mouse):
            WIN.blit(BUTTON_AGAIN_RED,(1090.00 - 102.5, 436.00 - 95, 205 , 190))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CLICK_SOUND.play()
                pygame.time.wait(1500)
                chips_menu()

                pass
            else:
                pass

        else:
            WIN.blit(BUTTON_AGAIN_WHITE,(1090.00 - 102.5, 436.00 - 95, 205 , 190))
            pygame.display.update()


def blocked():
    WIN.blit(BUTTON_HIT_RED,(736 - 60, 670 - 32))
    WIN.blit(BUTTON_DOUBLE_RED,(360 - 60, 670 - 32))
    WIN.blit(BUTTON_SPLIT_RED,(916 - 60, 670 - 32))
    WIN.blit(BUTTON_STAND_RED,(535 - 60, 670 - 32))
    pygame.display.update()

def draw_winner():
    if PLAYER.check_len_of_card_list() == 2: # Blackjack check, if player has 2 cards check for blackjack
        if PLAYER.check_total() == 21:
            blocked()
            pygame.time.wait(2000)
            PLAYER_CHIPS.append(CHIPS.bet_total() * 2.5)
            play_again()
    if PLAYER.check_total() > 21: # If Player has too many
        blocked()
        pygame.time.wait(2000)
        WIN.blit(LOSE_IMG,(636 - 465, 201 - 79))
        pygame.display.update()
        play_again()

    if DEALER.check_total() > 21: # If Dealer Busts
        show_total_dealer()
        blocked()
        pygame.time.wait(2000)
        # ADD PLAYER CHIPS
        for i in double_check: # if player Doubled add x 4 if not add x2
            if i == 1:
                PLAYER_CHIPS.append(CHIPS.bet_total() * 4)
            else:
                PLAYER_CHIPS.append(CHIPS.bet_total() * 2)
        WIN.blit(WIN_IMG,(630 - 311.5, 201 - 78))
        pygame.display.update()
        play_again()
    elif DEALER.check_total() <= 21: # Dealer doesn't Bust
        if DEALER.check_total() in range(17, 22): # If the Dealer cards are between 17 and 21, check for winner
            if PLAYER.check_total() > DEALER.check_total():
                show_total_dealer()
                blocked()
                pygame.time.wait(2000)
                # If Player has more than Dealer
                # ADD PLAYER CHIPS
                for i in double_check: # if player Doubled add x 4 if not add x2
                    if i == 1:
                        PLAYER_CHIPS.append(CHIPS.bet_total() * 4)
                    else:
                        PLAYER_CHIPS.append(CHIPS.bet_total() * 2)
                WIN.blit(WIN_IMG,(630 - 311.5, 201 - 78))
                pygame.display.update()
                play_again()
            if PLAYER.check_total() < DEALER.check_total():
                show_total_dealer()
                blocked()
                pygame.time.wait(2000)
                WIN.blit(LOSE_IMG,(636 - 465, 201 - 79))
                pygame.display.update()
                # If Dealer has more than Player
                play_again()
            if PLAYER.check_total() == DEALER.check_total():
                show_total_dealer()
                blocked()
                pygame.time.wait(2000)
                # Push
                # GIVE PLAYER BACK THE CHIPS IN CASE OF PUSH
                for i in double_check:
                    if i == 1:
                        PLAYER_CHIPS.append(CHIPS.bet_total() * 2)
                    else:
                        PLAYER_CHIPS.append(CHIPS.bet_total())
                play_again()


PLAYER = Card('P_CARDS_LIST')
DEALER = Card('D_CARDS_LIST')

def show_total_player():
    total_font = pygame.font.SysFont('Acumin Variable Concept', 80)
    for i in table_list:
        if i == 1:
            show_total = total_font.render(f'{PLAYER.check_total()}', False, (0, 0, 0))
            WIN.blit(TOTAL_IMG,(598, 543))
            WIN.blit(show_total,(610, 562))
        if i == 2:
            show_total = total_font.render(f'{PLAYER.check_total()}', False, (255, 255, 255))
            WIN.blit(TOTAL2_IMG,(598, 543))
            WIN.blit(show_total,(610, 562))
    pygame.display.update()

def show_total_dealer():
    dealer_total_font = pygame.font.SysFont('Acumin Variable Concept', 80)
    for i in table_list:
        if i == 1:
            dealer_show_total = dealer_total_font.render(f'{DEALER.check_total()}', False, (0, 0, 0))
            WIN.blit(DEALER_TOTAL_IMG,(327, 27))
            WIN.blit(dealer_show_total,(338, 44))
        if i == 2:
            dealer_show_total = dealer_total_font.render(f'{DEALER.check_total()}', False, (255, 255, 255))
            WIN.blit(DEALER_TOTAL2_IMG,(327, 27))
            WIN.blit(dealer_show_total,(338, 44))
    pygame.display.update()


def is_over(rect, pos):
    return True if rect.collidepoint(pos[0], pos[1]) else False

WIN.fill(BLACK)

def play():
    double_check.clear()
    PLAYER.clear_list()
    DEALER.clear_list()
    width_remove.clear()
    height_remove.clear()
    d_width_remove.clear()
    run = True
    lock_button_all = False
    lock_button_double_split = False
    stand = False
    double = False
    WIN.fill(BLACK)
    for i in table_list:
        if i == 1:
            WIN.blit(TABLE,(0,0))
        if i == 2:
            WIN.blit(TABLE_2,(0,0))
    WIN.blit(BUTTON_DOUBLE_BRIGHT,(360 - 60, 670 - 32))
    WIN.blit(BUTTON_HIT_BRIGHT,(736 - 60, 670 - 32))
    WIN.blit(BUTTON_SPLIT_BRIGHT,(916 - 60, 670 - 32))
    WIN.blit(BUTTON_STAND_BRIGHT,(535 - 60, 670 - 32))
    if 1 in chips_on_table:
        WIN.blit(SMALL_1,(515, 462))
    if 5 in chips_on_table:
        WIN.blit(SMALL_5,(500, 492))
    if 10 in chips_on_table:
        WIN.blit(SMALL_10,(490, 437))
    if 25 in chips_on_table:
        WIN.blit(SMALL_25,(550, 453))
    if 50 in chips_on_table:
        WIN.blit(SMALL_50,(525, 432))
    show_player_chips()
    pygame.display.update()
    PLAYER.player_add_card()
    DEALER.dealer_add_card()
    PLAYER.player_add_card()
    draw_winner()
    dealer_second_card = DEALER.dealer_add_card()
    pygame.time.wait(1500)
    pygame.display.update()
    clock = pygame.time.Clock()
    while run:
        mouse = pygame.mouse.get_pos()
        run = True
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                exit()
        pygame.display.update()
        mouse = pygame.mouse.get_pos()
        if CHIPS.bet_total() > sum(PLAYER_CHIPS): # lock split and double if player doesn't have as much chips as the bet amount
            lock_button_double_split = True
        if stand == True or double == True:
            if DEALER.check_total() in range(2,17): # If dealer has lower than 17 add more cards
                DEALER.dealer_add_card()

            if DEALER.check_total() >= 17: # If dealer has more than 16 break the loop and check for win
                draw_winner()
        else:
            # HANDLES THE HIT BUTTON
            if lock_button_all == False:
                if is_over(BUTTON_HIT_RECT, mouse):
                    WIN.blit(BUTTON_HIT_LIGHT,(736 - 60, 670 - 32))
                    pygame.display.update()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        CLICK_SOUND.play()
                        PLAYER.player_add_card()
                        lock_button_double_split = True
                        if PLAYER.check_total() > 21:
                            lock_button_all = True
                            draw_winner()
                        else:
                            pass
                        pass
                    else:
                        pass

                else:
                    WIN.blit(BUTTON_HIT_BRIGHT,(736 - 60, 670 - 32))
                    pygame.display.update()
            else:
                WIN.blit(BUTTON_HIT_RED,(736 - 60, 670 - 32))
                pygame.display.update()
            #----------------------------#
            # HANDLE STAND BUTTON
            if lock_button_all == False:
                if is_over(BUTTON_STAND_RECT, mouse):
                    WIN.blit(BUTTON_STAND_LIGHT,(535 - 60, 670 - 32))
                    pygame.display.update()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        CLICK_SOUND.play()
                        WIN.blit(BUTTON_HIT_RED,(736 - 60, 670 - 32))
                        WIN.blit(BUTTON_DOUBLE_RED,(360 - 60, 670 - 32))
                        WIN.blit(BUTTON_SPLIT_RED,(916 - 60, 670 - 32))
                        WIN.blit(BUTTON_STAND_RED,(535 - 60, 670 - 32))
                        if dealer_second_card == 2:
                            DEALER.add_list(2)
                            WIN.blit(DCARD_2, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 3:
                            DEALER.add_list(3)
                            WIN.blit(DCARD_3, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 4:
                            DEALER.add_list(4)
                            WIN.blit(DCARD_4, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 5:
                            DEALER.add_list(5)
                            WIN.blit(DCARD_5, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 6:
                            DEALER.add_list(6)
                            WIN.blit(DCARD_6, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 7:
                            DEALER.add_list(7)
                            WIN.blit(DCARD_7, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 8:
                            DEALER.add_list(8)
                            WIN.blit(DCARD_8, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 9:
                            DEALER.add_list(9)
                            WIN.blit(DCARD_9, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 10:
                            DEALER.add_list(10)
                            WIN.blit(DCARD_10, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 11:
                            DEALER.add_list(10)
                            WIN.blit(DCARD_J, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 12:
                            DEALER.add_list(10)
                            WIN.blit(DCARD_Q, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 13:
                            DEALER.add_list(10)
                            WIN.blit(DCARD_K, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                        if dealer_second_card == 14:
                            DEALER.add_list(11)
                            WIN.blit(DCARD_A, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            DEALER.too_many_fix()
                        d_width_remove.append(-20)
                        show_total_dealer()
                        pygame.display.update()
                        lock_button_all = True
                        stand = True

                    else:
                        pass

                else:
                    WIN.blit(BUTTON_STAND_BRIGHT,(535 - 60, 670 - 32))
                    pygame.display.update()
            else:
                WIN.blit(BUTTON_STAND_RED,(535 - 60, 670 - 32))
                pygame.display.update()
            #----------------------------#
            # HANDLE SPLIT BUTTON
            if lock_button_double_split == False: # If split wasn't pressed
                if lock_button_all == False:
                    if is_over(BUTTON_SPLIT_RECT, mouse):
                        WIN.blit(BUTTON_SPLIT_LIGHT,(916 - 60, 670 - 32))
                        pygame.display.update()

                        if event.type == pygame.MOUSEBUTTONDOWN:
                            CLICK_SOUND.play()
                            lock_button_double_split = True

                        else:
                            pass

                    else:
                        WIN.blit(BUTTON_SPLIT_BRIGHT,(916 - 60, 670 - 32))
                        pygame.display.update()
                else:
                    WIN.blit(BUTTON_SPLIT_RED,(916 - 60, 670 - 32))
                    pygame.display.update()
            else: # If Split was pressed
                    WIN.blit(BUTTON_SPLIT_RED,(916 - 60, 670 - 32))
                    pygame.display.update()
            #----------------------------#
            # HANDLE DOUBLE BUTTON
            if lock_button_double_split == False: # If split wasn't pressed
                if lock_button_all == False:
                    if is_over(BUTTON_DOUBLE_RECT, mouse):
                        WIN.blit(BUTTON_DOUBLE_LIGHT,(360 - 60, 670 - 32))
                        pygame.display.update()

                        if event.type == pygame.MOUSEBUTTONDOWN:
                            CLICK_SOUND.play()
                            PLAYER_CHIPS.append(- CHIPS.bet_total())
                            show_player_chips()
                            PLAYER.player_add_card()
                            WIN.blit(BUTTON_HIT_RED,(736 - 60, 670 - 32))
                            WIN.blit(BUTTON_DOUBLE_RED,(360 - 60, 670 - 32))
                            WIN.blit(BUTTON_SPLIT_RED,(916 - 60, 670 - 32))
                            WIN.blit(BUTTON_STAND_RED,(535 - 60, 670 - 32))
                            if dealer_second_card == 2:
                                DEALER.add_list(2)
                                WIN.blit(DCARD_2, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 3:
                                DEALER.add_list(3)
                                WIN.blit(DCARD_3, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 4:
                                DEALER.add_list(4)
                                WIN.blit(DCARD_4, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 5:
                                DEALER.add_list(5)
                                WIN.blit(DCARD_5, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 6:
                                DEALER.add_list(6)
                                WIN.blit(DCARD_6, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 7:
                                DEALER.add_list(7)
                                WIN.blit(DCARD_7, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 8:
                                DEALER.add_list(8)
                                WIN.blit(DCARD_8, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 9:
                                DEALER.add_list(9)
                                WIN.blit(DCARD_9, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 10:
                                DEALER.add_list(10)
                                WIN.blit(DCARD_10, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 11:
                                DEALER.add_list(10)
                                WIN.blit(DCARD_J, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 12:
                                DEALER.add_list(10)
                                WIN.blit(DCARD_Q, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 13:
                                DEALER.add_list(10)
                                WIN.blit(DCARD_K, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                            if dealer_second_card == 14:
                                DEALER.add_list(11)
                                WIN.blit(DCARD_A, (D_CARD_POS_WIDTH - sum(d_width_remove), D_CARD_POS_HEIGHT))
                                DEALER.too_many_fix()
                            d_width_remove.append(-20)
                            show_total_dealer()
                            pygame.display.update()
                            lock_button_all = True
                            double = True
                            double_check.append(1)
                        else:
                            pass

                    else:
                        WIN.blit(BUTTON_DOUBLE_BRIGHT,(360 - 60, 670 - 32))
                        pygame.display.update()
                elif lock_button_all == True:
                    WIN.blit(BUTTON_DOUBLE_RED,(360 - 60, 670 - 32))
                    pygame.display.update()
            else: # If Split was pressed
                    WIN.blit(BUTTON_DOUBLE_RED,(360 - 60, 670 - 32))
                    pygame.display.update()
            #----------------------------#

def main():
    WIN.blit(MENU_BACKGROUND,(0,0))
    WIN.blit(MINI_TABLE,(640 -162, 612 -92))
    WIN.blit(PLAY_WHITE,(WIDTH//2- 235.5, HEIGHT//2 -140))
    WIN.blit(QUIT_WHITE,(WIDTH//2- 235.5, HEIGHT//2 -20))
    WIN.blit(CHANGE_WHITE,(640 -118.5, 484 -28.5))
    pygame.display.update()
    clock = pygame.time.Clock()
    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                exit()

        pygame.display.update()


        mouse = pygame.mouse.get_pos()
        if is_over(MAIN_PLAY_BUTTON, mouse):

            WIN.blit(PLAY_RED,(WIDTH//2- 235.5, HEIGHT//2 -140))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CLICK_SOUND.play()
                pygame.time.wait(500)
                WIN.fill(BLACK)
                chips_menu()

            else:
                pass

        else:
            WIN.blit(PLAY_WHITE,(WIDTH//2 -235.5, HEIGHT//2 -140))
            pygame.display.update()

        if is_over(MAIN_QUIT_BUTTON, mouse):
            WIN.blit(QUIT_RED,(WIDTH//2- 235.5, HEIGHT//2 -20))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CLICK_SOUND.play()
                pygame.time.wait(500)
                run = False
                pygame.quit()
                exit()
            else:
                pass

        else:
            WIN.blit(QUIT_WHITE,(WIDTH//2 -235.5, HEIGHT//2 -20))
            pygame.display.update()

        if is_over(CHANGE_BUTTON, mouse):
            WIN.blit(CHANGE_RED,(640 -118.5, 484 -28.5))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CLICK_SOUND.play()
                for i in table_list:
                    if i == 1:
                        table_list.clear()
                        table_list.append(2)
                        WIN.blit(MINI_TABLE2,(640 -162, 612 -92))
                        pygame.display.update()
                    if i == 2:
                        table_list.clear()
                        table_list.append(1)
                        WIN.blit(MINI_TABLE,(640 -162, 612 -92))
                        pygame.display.update()
                pygame.time.wait(500)
            else:
                pass

        else:
            WIN.blit(CHANGE_WHITE,(640 -118.5, 484 -28.5))
            pygame.display.update()

    pygame.quit()

main()

