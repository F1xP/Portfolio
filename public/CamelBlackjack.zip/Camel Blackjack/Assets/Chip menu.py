import pygame
import os
import time

pygame.init()

WIDTH, HEIGHT = 1280, 720
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Camel BlackJack")

FPS = 60
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
RED = (250, 0, 0)
WHITE = (255, 255, 230)
PLAYER_CHIPS = [5000]

TABLE = pygame.image.load(os.path.join('Assets', 'table.png'))
CHIP_1_WHITE = pygame.image.load(os.path.join('Assets', 'chip_1_white.png'))
CHIP_1_RED = pygame.image.load(os.path.join('Assets', 'chip_1_red.png'))

CHIP_2_WHITE = pygame.image.load(os.path.join('Assets', 'chip_5_white.png'))
CHIP_2_RED = pygame.image.load(os.path.join('Assets', 'chip_5_red.png'))

CHIP_3_WHITE = pygame.image.load(os.path.join('Assets', 'chip_10_white.png'))
CHIP_3_RED = pygame.image.load(os.path.join('Assets', 'chip_10_red.png'))

CHIP_4_WHITE = pygame.image.load(os.path.join('Assets', 'chip_25_white.png'))
CHIP_4_RED = pygame.image.load(os.path.join('Assets', 'chip_25_red.png'))

CHIP_5_WHITE = pygame.image.load(os.path.join('Assets', 'chip_50_white.png'))
CHIP_5_RED = pygame.image.load(os.path.join('Assets', 'chip_50_red.png'))

DEAL_WHITE = pygame.image.load(os.path.join('Assets', 'deal_white.png'))
DEAL_RED = pygame.image.load(os.path.join('Assets', 'deal_red.png'))

BET_AMOUNT = pygame.image.load(os.path.join('Assets', 'bet_amount.png'))

CHIPS_AGAIN_WHITE = pygame.image.load(os.path.join('Assets', 'again_button_40.png'))
CHIPS_AGAIN_RED = pygame.image.load(os.path.join('Assets', 'again_button_2_40.png'))
CHIPS_AGAIN_RECT = pygame.Rect(1060  -20, 400 -20, 40 , 40) # Again BUTTON RECT

CHIP_1_BUTTON = pygame.Rect(160 -85, 230 -85, 170, 170)
CHIP_2_BUTTON = pygame.Rect(390 -85, 230 -85, 170, 170)
CHIP_3_BUTTON = pygame.Rect(620 -85, 230 -85, 170, 170)
CHIP_4_BUTTON = pygame.Rect(850 -85, 230 -85, 170, 170)
CHIP_5_BUTTON = pygame.Rect(1120 -85, 230 -85, 170, 170)
DEAL_BUTTON = pygame.Rect((640 -235.5, 535 -71.5, 471, 183))

class Chips:
    def __init__(self, amount):
        self.amount = amount
        self.amount = []

    def add_chips_1(self):
        self.amount.append(1)
    def add_chips_5(self):
        self.amount.append(5)
    def add_chips_10(self):
        self.amount.append(10)
    def add_chips_25(self):
        self.amount.append(25)
    def add_chips_50(self):
        self.amount.append(50)

    def bet_total(self):
        x = sum(self.amount)
        return x

    def clear_bet(self):
        self.amount.clear()


def is_over(rect, pos):
    return True if rect.collidepoint(pos[0], pos[1]) else False

CHIPS = Chips('BET')

def show_bet_chips():
    chips_total_font = pygame.font.SysFont('Acumin Variable Concept', 100)
    chips_show_total = chips_total_font.render(f'{CHIPS.bet_total()}', False, (0, 0, 0))
    WIN.blit(chips_show_total,(800, 370))
    pygame.display.update()

def show_player_chips():
    player_chips_font = pygame.font.SysFont('Acumin Variable Concept', 100)
    chips_player_show = player_chips_font.render(f'{CHIPS.bet_total()}', False, (0, 0, 0))
    WIN.blit(chips_player_show,(800, 370))
    pygame.display.update()

def chips_menu():
    WIN.fill(WHITE)
    WIN.blit(BET_AMOUNT,(640 -371, 400 -41))
    WIN.blit(CHIP_1_WHITE,(160 -85, 230 -85))
    WIN.blit(CHIP_2_WHITE,(390 -85, 230 -85))
    WIN.blit(CHIP_3_WHITE,(620 -85, 230 -85))
    WIN.blit(CHIP_4_WHITE,(850 -85, 230 -85))
    WIN.blit(CHIP_5_WHITE,(1120 -85, 230 -85))
    WIN.blit(DEAL_WHITE,(640 -235.5, 535 -71.5))
    clock = pygame.time.Clock()
    run = True
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                exit()

        pygame.display.update()


        mouse = pygame.mouse.get_pos()
        if is_over(CHIP_1_BUTTON, mouse):

            WIN.blit(CHIP_1_RED,(160 -85, 230 -85))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CHIPS.add_chips_1()
                pygame.time.wait(500)
                print(CHIPS.bet_total())
                WIN.blit(BET_AMOUNT,(640 -371, 400 -41))
                pygame.display.update()
                show_bet_chips()
            else:
                pass

        else:
            WIN.blit(CHIP_1_WHITE,(160 -85, 230 -85))
            pygame.display.update()

        if is_over(CHIP_2_BUTTON, mouse):

            WIN.blit(CHIP_2_RED,(390 -85, 230 -85))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CHIPS.add_chips_5()
                pygame.time.wait(500)
                WIN.blit(BET_AMOUNT,(640 -371, 400 -41))
                pygame.display.update()
                show_bet_chips()
            else:
                pass

        else:
            WIN.blit(CHIP_2_WHITE,(390 -85, 230 -85))
            pygame.display.update()

        if is_over(CHIP_3_BUTTON, mouse):

            WIN.blit(CHIP_3_RED,(620 -85, 230 -85))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CHIPS.add_chips_10()
                pygame.time.wait(500)
                WIN.blit(BET_AMOUNT,(640 -371, 400 -41))
                pygame.display.update()
                show_bet_chips()
            else:
                pass

        else:
            WIN.blit(CHIP_3_WHITE,(620 -85, 230 -85))
            pygame.display.update()

        if is_over(CHIP_4_BUTTON, mouse):

            WIN.blit(CHIP_4_RED,(850 -85, 230 -85))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CHIPS.add_chips_25()
                pygame.time.wait(500)
                WIN.blit(BET_AMOUNT,(640 -371, 400 -41))
                pygame.display.update()
                show_bet_chips()
            else:
                pass

        else:
            WIN.blit(CHIP_4_WHITE,(850 -85, 230 -85))
            pygame.display.update()

        if is_over(CHIP_5_BUTTON, mouse):

            WIN.blit(CHIP_5_RED,(1120 -85, 230 -85))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                CHIPS.add_chips_50()
                pygame.time.wait(500)
                WIN.blit(BET_AMOUNT,(640 -371, 400 -41))
                pygame.display.update()
                show_bet_chips()
            else:
                pass

        else:
            WIN.blit(CHIP_5_WHITE,(1120 -85, 230 -85))
            pygame.display.update()

        if is_over(DEAL_BUTTON, mouse):

            WIN.blit(DEAL_RED,(640 -235.5, 535 -71.5))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                # TAKES CHIPS FROM PLAYER
                PLAYER_CHIPS.append(- CHIPS.bet_total())
                pygame.time.wait(500)
                play()
            else:
                pass

        else:
            WIN.blit(DEAL_WHITE,(640 -235.5, 535 -71.5))
            pygame.display.update()

        if is_over(CHIPS_AGAIN_RECT, mouse):

            WIN.blit(CHIPS_AGAIN_RED,(1060  -20, 400 -20))
            pygame.display.update()

            if event.type == pygame.MOUSEBUTTONDOWN:
                # TAKES CHIPS FROM PLAYER
                CHIPS.clear_bet()
                WIN.blit(BET_AMOUNT,(640 -371, 400 -41))
                pygame.display.update()
                show_bet_chips()
                pygame.time.wait(500)
            else:
                pass

        else:
            WIN.blit(CHIPS_AGAIN_WHITE,(1060  -20, 400 -20))
            pygame.display.update()

    pygame.quit()

if __name__ == "__main__":
    main()